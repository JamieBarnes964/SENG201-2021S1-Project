/**
 * Contains user interface classes that provide user interface support and functionality for the GameEnvironment.
 */
package ui;