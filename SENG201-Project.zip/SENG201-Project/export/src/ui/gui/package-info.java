/**
 * Contains user interface classes that provide a graphical interface support and functionality for the GameEnvironment.
 */
package ui.gui;